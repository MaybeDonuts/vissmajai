<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AdminOrderController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProductController;

Route::get('/discounted-products', [ProductController::class, 'discounted'])->name('products.discounted');



Route::middleware(['auth'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'index'])->name('profile.index');
    Route::post('/profile/update', [ProfileController::class, 'update'])->name('profile.update');
    Route::post('/profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password');
});


// Группа маршрутов для управления заказами (доступна только админам и сотрудникам)
Route::middleware(['auth'])->group(function () {
    Route::middleware(['role:admin,employee'])->group(function () {
        Route::get('/admin/orders', [AdminOrderController::class, 'index'])->name('admin.orders');
        Route::get('/admin/orders/{order}', [AdminOrderController::class, 'show'])->name('admin.orders.show');
        Route::post('/admin/orders/{order}/status', [AdminOrderController::class, 'updateStatus'])->name('admin.orders.status');
        Route::get('/admin/orders/new', [AdminOrderController::class, 'newOrders'])->name('admin.orders.new')->middleware('role:employee');
        Route::post('/admin/orders/{order}/viewed', [AdminOrderController::class, 'markViewed'])->name('admin.orders.markViewed')->middleware('role:employee');

    });
});


Route::resource('products', ProductController::class);


Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::resource('categories', CategoryController::class);


//cart 
Route::post('/cart/add/{id}', [CartController::class, 'addToCart'])->name('cart.add');
Route::get('/cart', [CartController::class, 'showCart'])->name('cart.show');
Route::post('/cart/remove/{id}', [CartController::class, 'removeFromCart'])->name('cart.remove');
Route::post('/cart/clear', [CartController::class, 'clearCart'])->name('cart.clear');
Route::post('/cart/update/{id}', [CartController::class, 'updateQuantity'])->name('cart.update');


//order
Route::get('/checkout', [OrderController::class, 'checkout'])->name('order.checkout');
Route::post('/checkout', [OrderController::class, 'placeOrder'])->name('order.place');
Route::get('/my-orders', [OrderController::class, 'index'])->name('orders.history')->middleware('auth');
Route::get('/payment/{order_id}', [OrderController::class, 'paymentPage'])->name('order.payment');
Route::post('/orders/{order}/cancel', [OrderController::class, 'cancel'])->name('orders.cancel')->middleware('auth');


Auth::routes();


Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
