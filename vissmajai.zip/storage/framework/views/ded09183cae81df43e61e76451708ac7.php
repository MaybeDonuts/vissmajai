

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Товары со скидками</h1>

    <?php if($products->isEmpty()): ?>
        <p>Сейчас нет товаров со скидками.</p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Название</th>
                    <th>Категория</th>
                    <th>Старая цена</th>
                    <th>Новая цена</th>
                    <th>Скидка</th>
                    <th>Действие</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->category->name ?? 'Без категории'); ?></td>
                        <td><del><?php echo e($product->price); ?> €</del></td>
                        <td class="text-danger"><?php echo e($product->discounted_price); ?> €</td>
                        <td>-<?php echo e($product->discount); ?>%</td>
                        <td>
                            <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary">В корзину</button>
                            </form>
                        </td>
                        <td>
                            <?php if($product->discount > 0 && 
                                (is_null($product->discount_start) || $product->discount_start <= now()) && 
                                (is_null($product->discount_end) || $product->discount_end >= now())): ?>
                                <span class="text-danger"><?php echo e($product->discounted_price); ?> €</span>
                                <small class="text-muted"><del><?php echo e($product->price); ?> €</del></small>
                            <?php else: ?>
                                <?php echo e($product->price); ?> €
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($products->links()); ?>

    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vissmajai\resources\views/products/discounted.blade.php ENDPATH**/ ?>