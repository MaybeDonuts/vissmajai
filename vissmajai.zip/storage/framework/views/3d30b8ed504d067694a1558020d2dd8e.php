

<?php $__env->startSection('content'); ?>
    <h1>Мои заказы</h1>

    <?php if(session('success')): ?>
        <p class="alert alert-success"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <?php if($orders->isEmpty()): ?>
        <p>У вас пока нет заказов.</p>
    <?php else: ?>
        <table class="table">
            <tr>
                <th>Дата заказа</th>
                <th>Общая сумма</th>
                <th>Статус</th>
            </tr>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->created_at->format('d.m.Y H:i')); ?></td>
                    <td><?php echo e($order->total_price); ?> €</td>
                    <td>В обработке</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vissmajai\resources\views/orders/history.blade.php ENDPATH**/ ?>