

<?php $__env->startSection('content'); ?>
    <h1>Редактировать товар</h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <div class="mb-3">
            <label for="discount" class="form-label">Скидка (%)</label>
            <input type="number" name="discount" id="discount" class="form-control" value="<?php echo e(old('discount', $product->discount)); ?>">
        </div>

        <div class="mb-3">
            <label for="discount_start" class="form-label">Начало скидки</label>
            <input type="datetime-local" name="discount_start" id="discount_start" class="form-control" value="<?php echo e(old('discount_start', $product->discount_start ? $product->discount_start->format('Y-m-d\TH:i') : '')); ?>">
        </div>

        <div class="mb-3">
            <label for="discount_end" class="form-label">Конец скидки</label>
    <       input type="datetime-local" name="discount_end" id="discount_end" class="form-control" value="<?php echo e(old('discount_end', $product->discount_end ? $product->discount_end->format('Y-m-d\TH:i') : '')); ?>">
        </div>


    <?php endif; ?>

    <form action="<?php echo e(route('products.update', $product)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label>Название:</label>
        <input type="text" name="name" value="<?php echo e($product->name); ?>" required>

        <label>Описание:</label>
        <textarea name="description"><?php echo e($product->description); ?></textarea>

        <label>Цена:</label>
        <input type="text" name="price" value="<?php echo e($product->price); ?>" required>

        <label>Количество:</label>
        <input type="number" name="stock" value="<?php echo e($product->stock); ?>" required>

        

        <label>Категория:</label>
        <select name="category_id">
            <option value="">Выберите категорию</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e($product->category_id == $category->id ? 'selected' : ''); ?>>
                    <?php echo e($category->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label>Изображение:</label>
        <?php if($product->image): ?>
            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" width="100">
        <?php endif; ?>
        <input type="file" name="image">

        <button type="submit">Сохранить</button>
    </form>

    <br>
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Назад к списку</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vissmajai\resources\views/products/edit.blade.php ENDPATH**/ ?>