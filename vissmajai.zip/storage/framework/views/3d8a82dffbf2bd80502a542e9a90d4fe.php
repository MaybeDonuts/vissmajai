

<?php $__env->startSection('content'); ?>
    <h1>Добавить товар</h1>
    
    <form action="<?php echo e(route('products.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label>Название товара:</label>
        <input type="text" name="name" required>
        
        <label>Описание:</label>
        <textarea name="description"></textarea>
        
        <label>Цена:</label>
        <input type="text" name="price" required>
        
        <label>Количество:</label>
        <input type="number" name="stock" required>
        
        <div class="mb-3">
            <label for="discount" class="form-label">Скидка (%)</label>
            <input type="number" name="discount" id="discount" class="form-control" value="<?php echo e(old('discount')); ?>">
        </div>

        <div class="mb-3">
            <label for="discount_start" class="form-label">Начало скидки</label>
            <input type="datetime-local" name="discount_start" id="discount_start" class="form-control" value="<?php echo e(old('discount_start')); ?>">
        </div>

        <div class="mb-3">
            <label for="discount_end" class="form-label">Конец скидки</label>
            <input type="datetime-local" name="discount_end" id="discount_end" class="form-control" value="<?php echo e(old('discount_end')); ?>">
        </div>

        
        <label>Категория:</label>
        <select name="category_id">
            <option value="">Выберите категорию</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        
        <button type="submit">Добавить</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vissmajai\resources\views/products/create.blade.php ENDPATH**/ ?>