

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Личный кабинет</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <h3>Обновление данных</h3>
    <form method="POST" action="<?php echo e(route('profile.update')); ?>">
        <?php echo csrf_field(); ?>
        <label>Имя:</label>
        <input type="text" name="name" value="<?php echo e($user->name); ?>" required class="form-control">

        <label>Телефон:</label>
        <input type="text" name="phone" value="<?php echo e($user->phone); ?>" class="form-control">

        <label>Адрес доставки:</label>
        <input type="text" name="address" value="<?php echo e($user->address); ?>" class="form-control">

        <button type="submit" class="btn btn-primary mt-2">Сохранить</button>
    </form>

    <hr>

    <h3>Смена пароля</h3>
    <form method="POST" action="<?php echo e(route('profile.password')); ?>">
        <?php echo csrf_field(); ?>
        <label>Текущий пароль:</label>
        <input type="password" name="current_password" required class="form-control">

        <label>Новый пароль:</label>
        <input type="password" name="password" required class="form-control">

        <label>Подтвердите новый пароль:</label>
        <input type="password" name="password_confirmation" required class="form-control">

        <button type="submit" class="btn btn-warning mt-2">Изменить пароль</button>
    </form>

    <hr>

    <h3>История заказов</h3>
    <table class="table">
        <thead>
            <tr>
                <th>Дата</th>
                <th>Сумма</th>
                <th>Статус</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($order->created_at->format('d.m.Y H:i')); ?></td>
            <td><?php echo e($order->total_price); ?> €</td>
            <td><?php echo e($order->status); ?></td>
            <td>
                <?php if($order->status == 'pending'): ?>
                    <form method="POST" action="<?php echo e(route('orders.cancel', $order->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Отменить</button>
                    </form>
                <?php else: ?>
                    <span class="text-muted">Отмена невозможна</span>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
            </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vissmajai\resources\views/profile/index.blade.php ENDPATH**/ ?>