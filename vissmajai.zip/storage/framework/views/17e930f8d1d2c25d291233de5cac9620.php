

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($product->name); ?></h1>
    <p><strong>Цена:</strong> <?php echo e($product->price); ?> €</p>
    <p><strong>Описание:</strong> <?php echo e($product->description); ?></p>
    
    <?php if($product->image): ?>
        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" width="300">
    <?php else: ?>
        <p>Нет изображения</p>
    <?php endif; ?>

    <br>
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">Назад к списку</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vissmajai\resources\views/products/show.blade.php ENDPATH**/ ?>