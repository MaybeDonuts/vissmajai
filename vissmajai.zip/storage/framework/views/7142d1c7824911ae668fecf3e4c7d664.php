

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Корзина</h1>

        <?php if(session('success')): ?>
            <p class="alert alert-success"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <?php if(empty($cart)): ?>
            <p>Корзина пуста.</p>
        <?php else: ?>
            <table class="table">
                <tr>
                    <th>Название</th>
                    <th>Цена</th>
                    <th>Количество</th>
                    <th>Общая стоимость</th>
                    <th>Действия</th>
                </tr>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item['name']); ?></td>
                        <td><?php echo e($item['price']); ?> €</td>
                        <td>
                            <input type="number" value="<?php echo e($item['quantity']); ?>" min="1"
                                   class="quantity-input"
                                   data-id="<?php echo e($id); ?>">
                        </td>
                        <td class="total-price" data-id="<?php echo e($id); ?>">
                            <?php echo e($item['price'] * $item['quantity']); ?> €
                        </td>
                        <td>
                            <form action="<?php echo e(route('cart.remove', $id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger">Удалить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>

            <h3>Итого: <span id="cart-total"><?php echo e(collect($cart)->sum(fn($item) => $item['price'] * $item['quantity'])); ?> €</span></h3>

            <a href="<?php echo e(route('order.checkout')); ?>" class="btn btn-success">Оформить заказ</a>
        <?php endif; ?>
    </div>

    <script>
    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('change', function() {
            let productId = this.dataset.id;
            let newQuantity = this.value;

            fetch(`/cart/update/${productId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({ quantity: newQuantity })
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                    location.reload(); // Перезагружаем страницу при ошибке
                } else {
                    document.querySelector(`.total-price[data-id="${productId}"]`).textContent = data.total_price + ' €';
                    document.querySelector('#cart-total').textContent = data.cart_total + ' €';
                }
            })
            .catch(error => console.error('Ошибка:', error));
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vissmajai\resources\views/cart/index.blade.php ENDPATH**/ ?>