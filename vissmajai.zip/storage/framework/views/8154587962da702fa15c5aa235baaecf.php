

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Мои заказы</h1>

    <?php if($orders->isEmpty()): ?>
        <p>У вас пока нет заказов.</p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Дата</th>
                    <th>Сумма</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($order->created_at); ?></td>
            <td><?php echo e($order->total_price); ?></td>
            <td><?php echo e($order->status); ?></td>
            <td>
                <?php if($order->status == 'pending'): ?>
                    <form method="POST" action="<?php echo e(route('orders.cancel', $order->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Отменить</button>
                    </form>
                <?php else: ?>
                    <span class="text-muted">Отмена невозможна</span>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

        </table>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vissmajai\resources\views/profile/orders.blade.php ENDPATH**/ ?>