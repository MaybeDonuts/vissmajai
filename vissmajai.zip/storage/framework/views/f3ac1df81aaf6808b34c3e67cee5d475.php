

<?php $__env->startSection('content'); ?>
    <h1>Оформление заказа</h1>

    <form action="<?php echo e(route('order.place')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Имя:</label>
        <input type="text" name="name" required>

        <label>Телефон:</label>
        <input type="text" name="phone" required>

        <label>Адрес доставки:</label>
        <input type="text" name="address" required>

        <label>Способ оплаты:</label>
        <select name="payment_method" required>
            <option value="наличные">Наличные</option>
            <option value="карта">Банковская карта</option>
            <option value="онлайн">Онлайн-оплата</option>
        </select>


        <h2>Ваш заказ</h2>
        <table class="table">
            <tr>
                <th>Название</th>
                <th>Цена</th>
                <th>Количество</th>
                <th>Общая стоимость</th>
            </tr>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['name']); ?></td>
                    <td><?php echo e($item['price']); ?> €</td>
                    <td><?php echo e($item['quantity']); ?></td>
                    <td><?php echo e($item['price'] * $item['quantity']); ?> €</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <button type="submit" class="btn btn-success">Подтвердить заказ</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vissmajai\resources\views/orders/checkout.blade.php ENDPATH**/ ?>