

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(isset($order)): ?>
        <h1>Оплата заказа #<?php echo e($order->id); ?></h1>
        <p>Сумма к оплате: <strong><?php echo e($order->total_price); ?> €</strong></p>
        <p>Оплата пока не подключена, но в реальном магазине здесь была бы форма оплаты.</p>
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Вернуться в магазин</a>
    <?php else: ?>
        <h1>Ошибка</h1>
        <p>Заказ не найден.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vissmajai\resources\views/orders/payment.blade.php ENDPATH**/ ?>